﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using RestSharp;

namespace m2mAIRMobile
{
	public class SLAuthenticator
	{
		public delegate void OnAuthenticationError(string title, string message, int code, string dismissCaption);


		private readonly M2MServer server;
		private readonly CancellationTokenSource tokenSource;

		private static SLAuthenticator instance;
		public static SLAuthenticator Instance 
		{
			get {
				if (instance == null)
					instance = new SLAuthenticator ();
				return instance; 
			}
		}
		private SLAuthenticator()
		{
			server = new M2MServer ("https://api.devicewise.com");
			tokenSource = new CancellationTokenSource();
		}

		public M2MServer Server { get { return server; } }



	
		// Authenticate with server
		public async Task AuthenticateAsync (string username, string password, OnAuthenticationError OnError, Action<UserDetails> onSuccess)
		{
			var token = tokenSource.Token;
			var bodyParams = new Dictionary<string, object> { { "username", "demo@devicewise.com" }, { "password", "demo123" }	};
//			var bodyParams = new Dictionary<string, object> { { "username", username }, { "password", password }	};

			var response = await server.PostAsync<string>("/rest/auth", null ,bodyParams, token);

			Console.WriteLine ("AuthenticateAsync(), ResponseCode: " + response.StatusCode + ", StatusMessage: " + response.StatusMessage);
			if (response.IsOkResponse())
			{
				onSuccess(new UserDetails (username, password, response.StatusMessage));
			}
			else
			{
				OnError("AuthenticationFailed", response.StatusMessage, 0x222D2A, "Ok");
			}
		}
	}
}

