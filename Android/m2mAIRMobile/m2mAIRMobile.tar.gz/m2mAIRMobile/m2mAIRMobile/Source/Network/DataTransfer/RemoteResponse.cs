﻿using System;

namespace m2mAIRMobile
{
	public class RemoteResponse<TResult>
	{
		public TResult Result 		{ set; get; }
		public string StatusCode 	{ set; get; }
		public string StatusMessage { set; get; }

		public bool IsOkResponse()
		{
			return StatusCode.Equals ("OK");
		}
	}
}