﻿using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

using Android.App;
using Android.Content;
using Android.OS;

using m2mAIRMobile.Shared;

namespace m2mAIRMobile
{
	[Activity (Label = "m2mAIRMobile", MainLauncher = true, Icon = "@drawable/icon")]
	public class LauncherActivity : BaseActivity
	{

		private readonly LauncherViewModel viewModel;

		public LauncherActivity()
		{
			viewModel = new LauncherViewModel ();
		}


		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);


			viewModel.UserNotRegistered += new EventHandler (PreRegister);
			viewModel.UserLoggedOut += new EventHandler (LoggedOut);
			viewModel.UserLoggedIn += new EventHandler (LoggedIn);


			Settings.Instance.SetRegistered (false);
			Settings.Instance.SetUserName (null);
			Settings.Instance.SetPassword ("1");
			Settings.Instance.SetSessionId (null);


			viewModel.GetLoginStatus ();

		}

		// 
		private void PreRegister(object sender, EventArgs e) 
		{
			Console.WriteLine ("PreRegister()");
			var intent = new Intent(this, typeof(RegisterAndLoginActivity));
			StartActivity(intent);
			Finish ();
		}

		// 
		private void LoggedOut(object sender, EventArgs e) 
		{
			Console.WriteLine ("LoggedOut");
			var intent = new Intent(this, typeof(RegisterAndLoginActivity));
			StartActivity(intent);
			Finish ();
		}

		// 
		private void LoggedIn(object sender, EventArgs e) 
		{
			Console.WriteLine ("LoggedIn");
			var intent = new Intent(this, typeof(ThingsActivity));
			StartActivity(intent);
			Finish ();
		}
	}
}


